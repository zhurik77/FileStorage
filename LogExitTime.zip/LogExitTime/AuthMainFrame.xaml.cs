﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace LogExitTime
{
    /// <summary>
    /// Логика взаимодействия для AuthMainFrame.xaml
    /// </summary>
    public partial class AuthMainFrame : Page
    {
        public AuthMainFrame()
        {
            InitializeComponent();
        }

        public static int DDOSProtect = 0;
        private void Button_Click(object sender, RoutedEventArgs e)
        {

            string CorLogin = "Admin";
            string CorPass = "1";
            DispatcherTimer LoginFail = new DispatcherTimer();
            LoginFail.Tick += LoginFail_Tick;
            if (DDOSProtect >= 3)
            {
                Logger.LogAdd($"Window blocked for 60 sec. {DDOSProtect} times failed login operation");
                MessageBox.Show("Окно заблокировано на 60 секунд");
                LoginButton.IsEnabled = false;
                LoginFail.Interval = new TimeSpan(0, 0, 60);
                LoginFail.Start();
            }
            else
            {
                if (CorLogin == LoginBox.Text && CorPass == PassBox.Text)
                {
                    Logger.LogAdd($"Login for \"{LoginBox.Text}\" complete");
                    Manager.MainFrame.Navigate(new MainAppFrame());
                }
                else
                {
                    DDOSProtect++;
                    Logger.LogAdd($"Login for \"{LoginBox.Text}\" failed");
                    MessageBox.Show("Неверный логин или пароль \n Проверьте правильность вводимых данных");
                    LoginBox.Text = "";
                    PassBox.Text = "";
                }
            }

        }

        private void LoginFail_Tick(object sender, EventArgs e)
        {
            LoginButton.IsEnabled = true;
            DDOSProtect = 0;
        }
    }
}
