﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace LogExitTime
{
    /// <summary>
    /// Логика взаимодействия для MainAppFrame.xaml
    /// </summary>
    public partial class MainAppFrame : Page
    {
        public static DispatcherTimer LoginFail = new DispatcherTimer();
        public MainAppFrame()
        {
            InitializeComponent();
            LoginFail.Tick += LoginFail_Tick;
            LoginFail.Interval = new TimeSpan(0, 0, 10);
            LoginFail.Start();
        }

        private void LoginFail_Tick(object sender, EventArgs e)
        {
            MessageBox.Show("Приносим извинения, но вы бездельник!\n Программа будет закрыта без возможности дальнейшего открытия!");
            Logger.LogAdd("Login time-out");
            Manager.MainFrame.Navigate(new AuthMainFrame());
            LoginFail.Stop();
            //Application.Current.Run();
            //Application.Current.Shutdown();

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Logger.LogAdd("Login time refresh");
            LoginFail.Stop();
            LoginFail.Start();
            Console.WriteLine(LoginFail);
            
        }
    }
}
