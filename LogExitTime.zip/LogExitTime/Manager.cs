﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace LogExitTime
{
    class Manager
    {
        public static Frame MainFrame { get; set; }
        public static Frame ButtonFrame { get; set; }
        public static Frame AuthFrame { get; set; }
        public static DateTime LastTimeAction { get; set; }
    }
    class Logger
    {
        public static void LogAdd(string operation)
        {
            string path = "./log.txt";
            StreamWriter AddLog = new StreamWriter(path, true, System.Text.Encoding.Default);
            AddLog.WriteLine(DateTime.Now + $"| {operation}");
            AddLog.Close();
        }
    }
}
